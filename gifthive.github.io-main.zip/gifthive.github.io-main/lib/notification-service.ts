import { prisma } from "@/lib/prisma"
import { sendEmail } from "@/lib/email-service"

export async function createNotification(userId: string, message: string) {
  const notification = await prisma.notification.create({
    data: {
      userId,
      message,
    },
  })

  const user = await prisma.user.findUnique({
    where: { id: userId },
  })

  if (user && user.email) {
    await sendEmail(user.email, "New Notification", message)
  }

  return notification
}

