"use client"

import { useState, useEffect } from "react"
import { Bell } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export function Notifications() {
  const [notifications, setNotifications] = useState([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    fetchNotifications()
  }, [])

  const fetchNotifications = async () => {
    const response = await fetch("/api/notifications")
    if (response.ok) {
      const data = await response.json()
      setNotifications(data)
    }
  }

  const markAsRead = async (id) => {
    const response = await fetch(`/api/notifications/${id}`, { method: "POST" })
    if (response.ok) {
      fetchNotifications()
    }
  }

  return (
    <div className="relative">
      <Button onClick={() => setIsOpen(!isOpen)} variant="ghost">
        <Bell className="w-5 h-5" />
        {notifications.length > 0 && (
          <span className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">
            {notifications.length}
          </span>
        )}
      </Button>
      {isOpen && (
        <Card className="absolute right-0 mt-2 w-80 z-10">
          <CardContent className="py-2">
            {notifications.length === 0 ? (
              <p>No new notifications</p>
            ) : (
              <ul className="space-y-2">
                {notifications.map((notification) => (
                  <li key={notification.id} className="flex justify-between items-center">
                    <span>{notification.message}</span>
                    <Button onClick={() => markAsRead(notification.id)} variant="ghost" size="sm">
                      Mark as read
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

