"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function ItemCard({ item, isOwner }) {
  const [isGifting, setIsGifting] = useState(false)
  const router = useRouter()

  const handleGift = async () => {
    setIsGifting(true)
    const response = await fetch(`/api/items/${item.id}/gift`, {
      method: "POST",
    })
    if (response.ok) {
      router.refresh()
    }
    setIsGifting(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{item.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p>{item.description}</p>
        {!isOwner && !item.giftedBy && (
          <Button onClick={handleGift} disabled={isGifting}>
            {isGifting ? "Gifting..." : "Gift This Item"}
          </Button>
        )}
        {!isOwner && item.giftedBy && <p>This item has been gifted</p>}
      </CardContent>
    </Card>
  )
}

