import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Share2, Archive, Trash2 } from 'lucide-react'

export function ListCard({ list }) {
  const [isSharing, setIsSharing] = useState(false)
  const [isArchiving, setIsArchiving] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const router = useRouter()

  const handleShare = async () => {
    setIsSharing(true)
    const response = await fetch(`/api/lists/${list.id}/share`, { method: "POST" })
    if (response.ok) {
      const { shareToken } = await response.json()
      // You might want to show this in a modal or copy to clipboard
      alert(`Share this link: ${window.location.origin}/lists/${list.id}?token=${shareToken}`)
    }
    setIsSharing(false)
  }

  const handleArchive = async () => {
    setIsArchiving(true)
    const response = await fetch(`/api/lists/${list.id}/archive`, { method: "POST" })
    if (response.ok) {
      router.refresh()
    }
    setIsArchiving(false)
  }

  const handleDelete = async () => {
    setIsDeleting(true)
    const response = await fetch(`/api/lists/${list.id}`, { method: "DELETE" })
    if (response.ok) {
      router.refresh()
    }
    setIsDeleting(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{list.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p>{list.items.length} items</p>
        <div className="flex space-x-2 mt-4">
          <Link href={`/lists/${list.id}`}>
            <Button variant="link">View List</Button>
          </Link>
          <Button onClick={handleShare} disabled={isSharing}>
            <Share2 className="w-4 h-4 mr-2" />
            {isSharing ? "Sharing..." : "Share"}
          </Button>
          <Button onClick={handleArchive} disabled={isArchiving}>
            <Archive className="w-4 h-4 mr-2" />
            {isArchiving ? "Archiving..." : "Archive"}
          </Button>
          <Button onClick={handleDelete} disabled={isDeleting} variant="destructive">
            <Trash2 className="w-4 h-4 mr-2" />
            {isDeleting ? "Deleting..." : "Delete"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

