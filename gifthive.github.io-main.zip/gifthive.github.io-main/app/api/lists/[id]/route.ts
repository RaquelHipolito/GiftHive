import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const list = await prisma.list.findUnique({
    where: { id: params.id },
  })

  if (!list || list.userId !== session.user.id) {
    return new NextResponse("Not found", { status: 404 })
  }

  await prisma.list.delete({
    where: { id: params.id },
  })

  return new NextResponse(null, { status: 204 })
}

