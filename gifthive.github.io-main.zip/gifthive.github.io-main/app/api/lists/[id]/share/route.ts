import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"
import crypto from "crypto"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const list = await prisma.list.findUnique({
    where: { id: params.id },
  })

  if (!list || list.userId !== session.user.id) {
    return new NextResponse("Not found", { status: 404 })
  }

  const shareToken = crypto.randomBytes(32).toString('hex')

  const updatedList = await prisma.list.update({
    where: { id: params.id },
    data: { shareToken },
  })

  return NextResponse.json({ shareToken: updatedList.shareToken })
}

