import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"

export async function PUT(req: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const { name, bio, avatar } = await req.json()

  const user = await prisma.user.update({
    where: { id: session.user.id },
    data: { name, bio, avatar },
  })

  return NextResponse.json(user)
}

