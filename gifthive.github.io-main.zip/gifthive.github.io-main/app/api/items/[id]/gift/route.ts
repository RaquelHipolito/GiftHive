import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"
import { createNotification } from "@/lib/notification-service"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const item = await prisma.giftItem.update({
    where: { id: params.id },
    data: { giftedBy: session.user.id },
  })

  const list = await prisma.list.findUnique({
    where: { id: item.listId },
    include: { user: true },
  })

  if (list) {
    await createNotification(
      list.userId,
      `Someone has gifted the item "${item.name}" from your list "${list.name}"`
    )
  }

  return NextResponse.json(item)
}

