import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const { name, description, listId } = await req.json()

  const item = await prisma.giftItem.create({
    data: {
      name,
      description,
      listId,
    },
  })

  return NextResponse.json(item)
}

