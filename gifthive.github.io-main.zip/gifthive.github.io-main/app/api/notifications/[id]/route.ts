import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { NextResponse } from "next/server"

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const notification = await prisma.notification.findUnique({
    where: { id: params.id },
  })

  if (!notification || notification.userId !== session.user.id) {
    return new NextResponse("Not found", { status: 404 })
  }

  const updatedNotification = await prisma.notification.update({
    where: { id: params.id },
    data: { isRead: true },
  })

  return NextResponse.json(updatedNotification)
}

