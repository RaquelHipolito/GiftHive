import './globals.css'
import { Inter } from 'next/font/google'
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "@/components/auth-provider"
import { Notifications } from "@/components/notifications"
import Link from 'next/link'
import Button from "@/components/button"

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Gift List App',
  description: 'Share your gift ideas with friends and family',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <AuthProvider>
            <header className="container mx-auto py-4">
              <nav className="flex justify-between items-center">
                <Link href="/">
                  <h1 className="text-2xl font-bold">Gift List App</h1>
                </Link>
                <div className="flex items-center space-x-4">
                  <Notifications />
                  <Link href="/profile">
                    <Button variant="ghost">Profile</Button>
                  </Link>
                  <Link href="/api/auth/signout">
                    <Button variant="ghost">Sign Out</Button>
                  </Link>
                </div>
              </nav>
            </header>
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

