import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import { prisma } from "@/lib/prisma"
import { AddItemForm } from "@/components/add-item-form"
import { ItemCard } from "@/components/item-card"

export default async function ListPage({ params }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect('/api/auth/signin')
  }

  const list = await prisma.list.findUnique({
    where: { id: params.id },
    include: { items: true },
  })

  if (!list) {
    return <div>List not found</div>
  }

  const isOwner = list.userId === session.user.id

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">{list.name}</h1>
      {isOwner && <AddItemForm listId={list.id} />}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        {list.items.map((item) => (
          <ItemCard key={item.id} item={item} isOwner={isOwner} />
        ))}
      </div>
    </div>
  )
}

